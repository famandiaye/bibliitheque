package sn.edu.isepdiamniadio.tic.dbe.famaa;

import sn.edu.isepdiamniadio.tic.dbe.famaa.Livres;

import java.util.List;

public interface LivreService {
    void ajouterLivre(Livre livre);

    void ajouterLivre(Livres livre);
    void supprimerLivre(int id);
    List<Livres> obtenirTousLesLivres();
}