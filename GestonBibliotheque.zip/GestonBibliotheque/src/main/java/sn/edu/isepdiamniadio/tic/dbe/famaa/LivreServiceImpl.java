package sn.edu.isepdiamniadio.tic.dbe.famaa;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class LivreServiceImpl implements LivreService {

    @PersistenceContext(unitName = "BibliothequePU")
    private EntityManager em;

    @Override
    public void ajouterLivre(Livres livre) {
        em.persist(livre);
    }


    @Override
    public void supprimerLivre(int id) {
        Livres livre = em.find(Livres.class, id);
        if (livre != null) {
            em.remove(livre);
        }
    }

    @Override
    public List<Livre> obtenirTousLesLivres() {
        return em.createQuery("SELECT l FROM Livre l", Livre.class).getResultList();
    }
}